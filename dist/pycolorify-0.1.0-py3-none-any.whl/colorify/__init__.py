from .core import Color
__version__ = "0.1.0"
